/* Created by julioverne */
window.onload=function(){
	var modmyiDivs = document.getElementsByTagName("div");
	for (var i = 0; i < modmyiDivs.length; i++) { if(modmyiDivs[i].id.indexOf('div-gpt-ad-') !== -1) {	modmyiDivs[i].style.display = "none"; } }
}