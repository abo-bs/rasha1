/* Created by julioverne */
window.onload=function(){
	//var adzodttd = document.getElementsByName("zodttdad");
	//for (var i = 0; i < adzodttd.length; i++) {	adzodttd[i].style.display = "none";	}
    //var adiframe = document.getElementsByTagName("iframe");
	//for (var i = 0; i < adiframe.length; i++) { if(adiframe[i].src.indexOf('coinurl.com') !== -1) { adiframe[i].style.display = "none"; } }
    var adzodttd = document.getElementsByTagName("div");
    for (var i = 0; i < adzodttd.length; i++) {	adzodttd[i].style.display = "none";  }
}