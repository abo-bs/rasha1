/* Created by julioverne */
window.onload=function(){
	var mainclas = document.getElementsByClassName("pinstripe")[0];
	var googleclass = mainclas.getElementsByClassName("adsbygoogle");
	for (var i = 0; i < googleclass.length; i++) {
	googleclass[i].style.display = "none";
	}
}